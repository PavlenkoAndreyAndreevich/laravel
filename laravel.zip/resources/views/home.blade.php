@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                     @can('admin')
                       <a href="{{ route('products') }}">Добавить товар</a>
                     @endcan

                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    Привет  @if (Auth::user())
                                {{ Auth::user()->name }} !
                            @else Гость!
                            @endif
                </div>
                <div class="container">

                    <div class="row">
                        <div class="section-title text-center col mb-30">
                            <h1>Popular Products</h1>
                            <p>All popular product find here</p>
                        </div>
                    </div>

                    <div class="row">


                        @foreach ($products as $product)
                            <div class="col-xl-3 col-lg-4 col-md-6 col-12 mb-40">

                                <div class="product-item">
                                    <div class="product-inner">

                                        <div class="image">
                                            <img src="{{asset("/uploads/$product->img")}}" alt="">

                                            <div class="image-overlay" style="height: 100%;">
                                                <div class="action-buttons">
                                                    <button>add to cart</button>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="content">
                                            <div class="content-left">
                                                <h4 class="title"><a href="single-product.html">{{ $product->title }}</a></h4>
                                            </div>

                                            <div class="content-right">
                                                <span class="price">{{ $product->price }}</span>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                            </div>
                        @endforeach



                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
