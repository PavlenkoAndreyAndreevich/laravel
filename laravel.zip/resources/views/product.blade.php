@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <form method="POST" action="{{ route('products.store') }}" enctype="multipart/form-data">
                @csrf

                <div class="form-group">
                    <label for="title" class="col-form-label">Title</label>
                    <input id="title" class="form-control{{ $errors->has('title') ? ' is-invalid' : '' }}" name="title" value="{{ old('title') }}" >
                    @if ($errors->has('title'))
                        <span class="invalid-feedback"><strong>{{ $errors->first('title') }}</strong></span>
                    @endif
                </div>

                <div class="form-group">
                    <label for="description" class="col-form-label">Description</label>
                    <input id="description" type="text" class="form-control{{ $errors->has('description') ? ' is-invalid' : '' }}" name="description" value="{{ old('description') }}" >
                    @if ($errors->has('description'))
                        <span class="invalid-feedback"><strong>{{ $errors->first('description') }}</strong></span>
                    @endif
                </div>

                <div class="form-group">
                    <label for="price" class="col-form-label">Price</label>
                    <input id="price" type="number" class="form-control{{ $errors->has('price') ? ' is-invalid' : '' }}" name="price" value="{{ old('price') }}" >
                    @if ($errors->has('price'))
                        <span class="invalid-feedback"><strong>{{ $errors->first('price') }}</strong></span>
                    @endif
                </div>

                <div class="form-group">
                    <label for="quantity" class="col-form-label">Quantity</label>
                    <input id="quantity" type="number" class="form-control{{ $errors->has('quantity') ? ' is-invalid' : '' }}" name="quantity" value="{{ old('quantity') }}" >
                    @if ($errors->has('quantity'))
                        <span class="invalid-feedback"><strong>{{ $errors->first('quantity') }}</strong></span>
                    @endif
                </div>

                <div class="form-group">
                    <label for="image" class="col-form-label">Image</label>
                    <input id="image" type="file" class="form-control{{ $errors->has('img') ? ' is-invalid' : '' }}" name="img" >

                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
