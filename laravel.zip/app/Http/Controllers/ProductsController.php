<?php

namespace App\Http\Controllers;
use App\Http\Requests\ProductRequest;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Product;


use Illuminate\Http\Request;

class ProductsController extends Controller
{

    public function index()
    {
        //
    }


    public function create()
    {
        return view('product');
    }


    public function store(ProductRequest $request)
    {
      //  $request->file('img')->storeAs('/public/storage', $request->file('img')->getClientOriginalName());

        $img = $request->file('img');
        $extension = $img->getClientOriginalExtension();
        Storage::disk('public')->put($request->file('img')->getClientOriginalName(),  File::get($img));

             Product::new(
                $request['title'],
                $request['description'],
                $request['price'],
                $request['quantity'],
                $request->file('img')->getClientOriginalName()

            );

        return redirect()->route('home');
    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {
        //
    }
}
