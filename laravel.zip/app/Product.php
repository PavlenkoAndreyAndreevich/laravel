<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Product extends Model
{
    protected $table = 'products';

    protected $fillable = ['title', 'description', 'price', 'quantity', 'img'];

    public static function new($title, $description, $price, $quantity, $img)
    {
        return static::create([
            'title' => $title,
            'description' => $description,
            'price' => $price,
            'quantity' => $quantity,
            'img'=>$img
        ]);
    }


}
