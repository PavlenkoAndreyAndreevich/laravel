<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <form method="POST" action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="title" class="col-form-label">Title</label>
                    <input id="title" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" value="<?php echo e(old('title')); ?>" >
                    <?php if($errors->has('title')): ?>
                        <span class="invalid-feedback"><strong><?php echo e($errors->first('title')); ?></strong></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="description" class="col-form-label">Description</label>
                    <input id="description" type="text" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description')); ?>" >
                    <?php if($errors->has('description')): ?>
                        <span class="invalid-feedback"><strong><?php echo e($errors->first('description')); ?></strong></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="price" class="col-form-label">Price</label>
                    <input id="price" type="number" class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" name="price" value="<?php echo e(old('price')); ?>" >
                    <?php if($errors->has('price')): ?>
                        <span class="invalid-feedback"><strong><?php echo e($errors->first('price')); ?></strong></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="quantity" class="col-form-label">Quantity</label>
                    <input id="quantity" type="number" class="form-control<?php echo e($errors->has('quantity') ? ' is-invalid' : ''); ?>" name="quantity" value="<?php echo e(old('quantity')); ?>" >
                    <?php if($errors->has('quantity')): ?>
                        <span class="invalid-feedback"><strong><?php echo e($errors->first('quantity')); ?></strong></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="image" class="col-form-label">Image</label>
                    <input id="image" type="file" class="form-control<?php echo e($errors->has('img') ? ' is-invalid' : ''); ?>" name="img" >

                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>