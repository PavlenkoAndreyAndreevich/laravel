<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                       <a href="<?php echo e(route('products')); ?>">Добавить товар</a>
                     <?php endif; ?>

                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Привет  <?php if(Auth::user()): ?>
                                <?php echo e(Auth::user()->name); ?> !
                            <?php else: ?> Гость!
                            <?php endif; ?>
                </div>
                <div class="container">

                    <div class="row">
                        <div class="section-title text-center col mb-30">
                            <h1>Popular Products</h1>
                            <p>All popular product find here</p>
                        </div>
                    </div>

                    <div class="row">


                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-12 mb-40">

                                <div class="product-item">
                                    <div class="product-inner">

                                        <div class="image">
                                            <img src="<?php echo e(asset("/uploads/$product->img")); ?>" alt="">

                                            <div class="image-overlay" style="height: 100%;">
                                                <div class="action-buttons">
                                                    <button>add to cart</button>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="content">
                                            <div class="content-left">
                                                <h4 class="title"><a href="single-product.html"><?php echo e($product->title); ?></a></h4>
                                            </div>

                                            <div class="content-right">
                                                <span class="price"><?php echo e($product->price); ?></span>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>